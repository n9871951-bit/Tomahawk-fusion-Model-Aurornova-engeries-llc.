"""Keep source PF-to-TF centerline separation while fitting PF placement.

The guard is derived from the starting layout, not a certified winding-pack
clearance. Full TF and PF conductor/support envelopes are still needed in CAD.
"""
import csv
import json
import numpy as np
from scipy.optimize import minimize
from scipy.spatial import cKDTree
from screen_windings import ROOT,Study,BLOCK,ORDER


def main():
    s=Study()
    rows=list(csv.DictReader((ROOT/"source_TF48_exact_centerlines_m.csv").open(newline="")))
    a=np.array([[float(r[k]) for k in ("x_m","y_m","z_m")] for r in rows])
    b=np.array([[float(r[k]) for k in ("next_x_m","next_y_m","next_z_m")] for r in rows])
    samples=(a[:,None,:]+np.linspace(0,1,9)[None,:,None]*(b-a)[:,None,:]).reshape(-1,3)
    tree=cKDTree(np.column_stack([np.hypot(samples[:,0],samples[:,1]),samples[:,2]]))
    sampling_bound=float(np.max(np.linalg.norm(b-a,axis=1))/16)
    original_min=float(tree.query(np.column_stack([s.original_r,s.original_z]))[0].min())
    reference_currents=s.operating.copy()
    output=[]
    for seed_name in ("PF578_placement_1m","PF634_reversed_sense_diagnostic"):
        previous=json.loads((ROOT/(seed_name+".json")).read_text())
        signs=np.array(previous.get("sign_multipliers",[1,1,1,1]))
        s.operating=reference_currents*signs[BLOCK]
        n=np.array([previous["turns_by_group"][g] for g in ORDER[:4]])
        f=np.array(previous["pack_aspect_factors"])
        def separation(p):
            pos,_,names=s.layout(n,p,f)
            distance=tree.query(pos)[0]
            return np.array([distance[np.array(names)==g].min()-sampling_bound-original_min for g in ORDER])
        def constraints(v):
            residual=np.r_[s.residuals(s.exact_field(n,v[:6],f))]/.1
            return np.r_[v[-1]-residual,v[-1]+residual,separation(v[:6])]
        runs=[]
        for p in (np.array(previous["placement_parameters_m"]),np.zeros(6)):
            x=np.r_[p,s.score(s.exact_field(n,p,f))/.1+1e-6]
            fit=minimize(lambda v:v[-1],x,method="SLSQP",bounds=[(-1.,1.)]*6+[(0.,2.)],
                constraints=[{"type":"ineq","fun":constraints}],
                options={"maxiter":180,"ftol":1e-10})
            if np.min(constraints(fit.x))>=-1e-7:
                runs.append(fit)
        if not runs:
            raise RuntimeError(f"No feasible separated fit for {seed_name}")
        fit=min(runs,key=lambda r:r.fun)
        p=fit.x[:6]
        name=seed_name+"_separation_guard"
        result,bn,bp=s.record(name,n,p,f,s.exact_field(n,p,f),{
            "sign_changes":bool(np.any(signs!=1)),"sign_multipliers":signs.tolist(),
            "selection_status":"GEOMETRY_STUDY_CANDIDATE_BOUNDARY_GATES_STILL_OPEN",
            "minimum_required_TF_centerline_lower_bound_m":original_min,
            "TF_sample_spacing_error_bound_m":sampling_bound,
            "minimum_constraint_margin_m":float(np.min(separation(p))),
            "exact_optimizer_success":bool(fit.success),"exact_optimizer_message":str(fit.message)})
        s.save_case(result,n,p,f,bn,bp)
        output.append(result)
        print(json.dumps(result,indent=2),flush=True)
    (ROOT/"separation_guard_results.json").write_text(json.dumps(output,indent=2)+"\n")

if __name__=="__main__":
    main()
