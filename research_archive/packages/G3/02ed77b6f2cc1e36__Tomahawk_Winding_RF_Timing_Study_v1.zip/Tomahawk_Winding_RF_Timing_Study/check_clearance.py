"""Centerline separation screen; DESC is needed for the plasma surface sample."""
import csv
import json
import numpy as np
from scipy.spatial import cKDTree
from desc.equilibrium import Equilibrium
from desc.grid import LinearGrid
from screen_windings import ROOT


def main():
    tf=list(csv.DictReader((ROOT/"source_TF48_exact_centerlines_m.csv").open(newline="")))
    a=np.array([[float(r[k]) for k in ("x_m","y_m","z_m")] for r in tf])
    b=np.array([[float(r[k]) for k in ("next_x_m","next_y_m","next_z_m")] for r in tf])
    t=np.linspace(0,1,9)
    points=(a[:,None,:]+t[None,:,None]*(b-a)[:,None,:]).reshape(-1,3)
    tf_tree=cKDTree(np.column_stack([np.hypot(points[:,0],points[:,1]),points[:,2]]))
    eq=Equilibrium.load(str(ROOT/"combined_high_pressure.h5"))
    grid=LinearGrid(rho=np.array([1.]),theta=np.linspace(0,2*np.pi,2048,endpoint=False),
                    zeta=np.linspace(0,2*np.pi/16,16,endpoint=False),NFP=16)
    surface=eq.compute(["R","Z"],grid=grid)
    tree=cKDTree(np.column_stack([surface["R"],surface["Z"]]))
    results={}
    for path in [ROOT/"source_PF578_turn_placement.csv"]+sorted(ROOT.glob("PF*_turn_placement.csv")):
        rows=list(csv.DictReader(path.open(newline="")))
        pos=np.array([[float(r["R_m"]),float(r["Z_m"])] for r in rows])
        distance= float(tf_tree.query(pos)[0].min())
        # Any point on a straight segment is <= half the sample step from a sample.
        spacing_bound=float(np.max(np.linalg.norm(b-a,axis=1))/16)
        results[path.name]={"PF_to_TF_centerline_sampled_min_m":distance,
            "PF_to_TF_centerline_lower_bound_m":max(0.,distance-spacing_bound),
            "PF_turn_center_to_sampled_plasma_surface_min_m":float(tree.query(pos)[0].min())}
    report={"method":"Exact PF circles to 9 points per TF line segment; plasma 2048 theta x 16 zeta points",
        "scope":"Centerlines only; TF winding envelopes, insulation, structural supports and services are not included",
        "cases":results}
    (ROOT/"clearance_results.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))

if __name__=="__main__":
    main()
