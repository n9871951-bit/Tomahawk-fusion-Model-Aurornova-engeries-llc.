"""Validate exported turns and recalculate their boundary scores.

Only NumPy and SciPy are required. This checks the exact exported decimal
coordinates, signed currents, integer counts, mirror symmetry, source pitch,
and analytic loop field against independent numerical Biot-Savart quadrature.
"""
import csv
import json
import numpy as np
from scipy.spatial.distance import pdist
from screen_windings import ROOT, Study, ORDER, PITCH, circular_field


def main():
    s=Study()
    results=[]
    for path in sorted(ROOT.glob("PF*_turn_placement.csv")):
        rows=list(csv.DictReader(path.open(newline="")))
        result=json.loads(path.with_name(path.name.replace("_turn_placement.csv",".json")).read_text())
        assert len(rows)==result["total_turns"]
        assert len(set(r["turn_id"] for r in rows))==len(rows)
        pos=np.array([[float(r["R_m"]),float(r["Z_m"])] for r in rows])
        amps=np.array([float(r["operating_current_A"]) for r in rows])
        assert np.isfinite(pos).all() and np.isfinite(amps).all()
        assert np.all(pos[:,0]>0)
        for g in ORDER:
            selected=pos[[r["coil_id"]==g for r in rows]]
            assert len(selected)==result["turns_by_group"][g]
            assert pdist(selected).min()>=PITCH-1e-9
        for lower,upper in (("PF_L_IN","PF_U_IN"),("PF_L_OUT","PF_U_OUT")):
            a={(r["R_m"],round(-float(r["Z_m"]),9)) for r in rows if r["coil_id"]==lower}
            b={(r["R_m"],round(float(r["Z_m"]),9)) for r in rows if r["coil_id"]==upper}
            assert a==b
        field=circular_field(s.ref["R"],s.ref["Z"],pos[:,0],pos[:,1],amps)
        normal,pressure=s.residuals(field)
        nerr=abs(float(np.max(abs(normal)))-result["normal_max"])
        perr=abs(float(np.max(abs(pressure)))-result["pressure_max"])
        assert max(nerr,perr)<1e-10
        results.append({"file":path.name,"turns":len(rows),"minimum_turn_spacing_verified_m":PITCH,
                        "normal_score_reproduction_error":nerr,"pressure_score_reproduction_error":perr})
    # Independent quadrature of dl cross (x-x')/|x-x'|^3 for two signed loops.
    R=np.array([1.2,4.3,8.0]);Z=np.array([-.7,.3,2.1])
    a=np.array([2.0,6.0]);zc=np.array([-.4,1.2]);I=np.array([12000.,-7000.])
    analytic=circular_field(R,Z,a,zc,I)
    nphi=16384
    phi=(np.arange(nphi)+.5)*(2*np.pi/nphi)
    numeric=np.zeros_like(analytic)
    for radius,height,amp in zip(a,zc,I):
        source=np.column_stack([radius*np.cos(phi),radius*np.sin(phi),np.full(nphi,height)])
        dl=np.column_stack([-radius*np.sin(phi),radius*np.cos(phi),np.zeros(nphi)])*(2*np.pi/nphi)
        d=np.column_stack([R,np.zeros_like(R),Z])[:,None,:]-source[None,:,:]
        numeric+=1e-7*amp*np.sum(np.cross(dl[None,:,:],d)/np.linalg.norm(d,axis=2)[:,:,None]**3,axis=1)
    rel=float(np.linalg.norm(analytic-numeric)/np.linalg.norm(numeric))
    assert rel<1e-10
    # Zero geometry/current change must reproduce both reference residuals.
    bn,bp=s.residuals(s.old_pf)
    assert np.array_equal(bn,s.ref["normal"]) and np.array_equal(bp,s.ref["pressure"])
    report={"status":"PASS","layouts":results,"loop_quadrature_relative_error":rel,
            "zero_change_reference_reproduced":True}
    (ROOT/"validation.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))

if __name__=="__main__":
    main()
