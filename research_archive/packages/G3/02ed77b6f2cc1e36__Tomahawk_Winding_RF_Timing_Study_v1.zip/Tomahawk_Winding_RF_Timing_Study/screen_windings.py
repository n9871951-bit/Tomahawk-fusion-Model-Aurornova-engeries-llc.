"""Reproducible fixed-equilibrium PF turn/placement screen (NumPy + SciPy).

The saved exact-map DESC residual is the reference. Only the field difference
from changed circular PF turns is added. TF, equilibrium, pressure and iota
stay fixed. This is not a new MGRID or a free-boundary equilibrium solve.
"""
import argparse
import csv
import itertools
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import ellipk, ellipe

ROOT = Path(__file__).resolve().parent
ORDER = ("PF_L_IN", "PF_L_OUT", "PF_M_IN", "PF_M_OUT", "PF_U_IN", "PF_U_OUT")
BLOCK = np.array([0, 1, 2, 3, 0, 1])
BASE_N = np.array([28, 162, 48, 150])
MULT = np.array([2, 2, 1, 1])
CENTERS = np.array([[4.,-4.25],[11.,-4.25],[2.5,0.],[12.5,0.],
                    [4.,4.25],[11.,4.25]])
ASPECT_Z_R = np.array([7/4, 18/9, 8/6, 15/10])
PITCH = 0.0297
GATE = 0.001


def circular_field(R, Z, a, zc, currents):
    """Full circular-loop field, cylindrical components, SI units."""
    R, Z, a, zc, currents = map(np.asarray, (R, Z, a, zc, currents))
    r = R[:, None]
    z = Z[:, None] - zc[None, :]
    a = a[None, :]
    plus = (a+r)**2+z*z
    minus = (a-r)**2+z*z
    if np.any(minus <= 1e-16) or np.any(r <= 0) or np.any(a <= 0):
        raise ValueError("Invalid loop radius or evaluation on a filament")
    m = 4*a*r/plus
    K, E = ellipk(m), ellipe(m)
    fac = 2e-7*currents/np.sqrt(plus)
    br = np.sum(fac*z/r*(-K+(a*a+r*r+z*z)/minus*E), axis=1)
    bz = np.sum(fac*(K+(a*a-r*r-z*z)/minus*E), axis=1)
    return np.column_stack([br,np.zeros_like(br),bz])


def shifted_centers(p):
    p = np.asarray(p)
    return CENTERS + np.array([[p[0],-p[1]],[p[2],-p[3]],[p[4],0.],
                              [p[5],0.],[p[0],p[1]],[p[2],p[3]]])


def pack_offsets(count, aspect):
    """Symmetric centered rows at source pitch; allow partial centered rows.

    Odd row counts allow any integer turn count while preserving exact Z
    reflection. Each row is also centered in R. This is a centerline layout.
    """
    count = int(count)
    target = np.sqrt(count*aspect)
    choices = np.arange(1,count+1,2)
    nz = int(choices[np.argmin(abs(choices-target))])
    q, rem = divmod(count,nz)
    lens = np.full(nz,q,dtype=int)
    mid = nz//2
    if rem % 2:
        lens[mid] += 1
    for k in range(1,rem//2+1):
        lens[mid-k] += 1
        lens[mid+k] += 1
    offsets = np.array([(PITCH*(j-(nr-1)/2),PITCH*(i-mid))
                        for i,nr in enumerate(lens) for j in range(nr)])
    assert len(offsets) == count
    assert np.allclose(offsets.mean(axis=0),0,atol=1e-14)
    return offsets


class Study:
    def __init__(self):
        self.ref = dict(np.load(ROOT / "boundary_reference.npz"))
        self.rows = list(csv.DictReader((ROOT / "source_PF578_turn_placement.csv").open(newline="")))
        assert len(self.rows) == 578
        self.nominal = np.array([float(next(r for r in self.rows if r["coil_id"]==g)
                                       ["signed_current_A"]) for g in ORDER])
        self.operating = 0.5*self.nominal
        self.original_r = np.array([float(r["R_m"]) for r in self.rows])
        self.original_z = np.array([float(r["Z_m"]) for r in self.rows])
        self.original_i = np.array([0.5*float(r["signed_current_A"]) for r in self.rows])
        self.old_pf = circular_field(self.ref["R"],self.ref["Z"],
            self.original_r,self.original_z,self.original_i)
        self.lo = np.ceil(0.75*BASE_N).astype(int)
        self.hi = np.floor(1.5*BASE_N).astype(int)

    def residuals(self, field):
        dB = field-self.old_pf
        d = self.ref
        normal = d["normal"]+np.sum(dB*d["n"],axis=1)*d["g"]/d["normal_scale"]
        pressure = d["pressure"]-(2*np.sum(d["Bout"]*dB,axis=1)+
                    np.sum(dB*dB,axis=1))*d["g"]/d["pressure_scale"]
        return normal,pressure

    def thin_field(self,n,p):
        centers=shifted_centers(p)
        return circular_field(self.ref["R"],self.ref["Z"],centers[:,0],centers[:,1],
                              self.operating*np.asarray(n)[BLOCK])

    def layout(self,n,p,factors=None):
        if factors is None:
            factors = np.ones(4)
        centers = shifted_centers(p)
        positions=[]; currents=[]; names=[]
        for i,g in enumerate(ORDER):
            block = BLOCK[i]
            off=pack_offsets(n[block],ASPECT_Z_R[block]*factors[block])
            pos = off+centers[i]
            positions.extend(pos)
            currents.extend([self.operating[i]]*len(pos))
            names.extend([g]*len(pos))
        return np.asarray(positions),np.asarray(currents),names

    def exact_field(self,n,p,factors=None):
        pos,amps,_ = self.layout(n,p,factors)
        return circular_field(self.ref["R"],self.ref["Z"],pos[:,0],pos[:,1],amps)

    def score(self,field):
        return max(np.max(abs(r)) for r in self.residuals(field))

    def continuous_fit(self,budget,envelope):
        # Fractional turns are used only to initialize the discrete design.
        bounds = list(zip(self.lo/BASE_N,self.hi/BASE_N)) + [(-envelope,envelope)]*6+[(0,2)]
        trials=[]
        for p in [np.zeros(6),np.array([0.,-envelope,-envelope,envelope,-envelope,envelope])]:
            x = np.r_[np.full(4,budget/578),p,1.]
            def constraints(v):
                normal,pressure = self.residuals(self.thin_field(v[:4]*BASE_N,v[4:10]))
                r=np.r_[normal,pressure]/0.1
                return np.r_[v[-1]-r,v[-1]+r]
            result = minimize(lambda v:v[-1],x,method="SLSQP",bounds=bounds,
                constraints=[{"type":"eq","fun":lambda v:(np.dot(v[:4]*BASE_N,MULT)-budget)/578},
                             {"type":"ineq","fun":constraints}],
                options={"maxiter":180,"ftol":1e-10})
            feasible=(abs(np.dot(result.x[:4]*BASE_N,MULT)-budget)<1e-5 and
                      np.min(constraints(result.x))>=-1e-6)
            trials.append({"x":result.x,"success":bool(result.success),"feasible":bool(feasible),
                           "message":str(result.message),"score":self.score(self.thin_field(
                               result.x[:4]*BASE_N,result.x[4:10]))})
        valid=[r for r in trials if r["feasible"]]
        if not valid:
            raise RuntimeError(f"No feasible continuous initialization: {trials}")
        return min(valid,key=lambda r:r["score"]),trials

    def round_counts(self,target,p,budget):
        ranges=[range(max(self.lo[i],int(round(target[i]))-3),
                      min(self.hi[i],int(round(target[i]))+3)+1) for i in range(3)]
        best=None
        for a,b,c in itertools.product(*ranges):
            n=np.array([a,b,c,budget-2*a-2*b-c])
            if self.lo[3] <= n[3] <= self.hi[3]:
                value=self.score(self.thin_field(n,p))
                if best is None or value<best[0]:
                    best=(value,n)
        if best is None:
            raise RuntimeError("No integer count allocation at the requested budget")
        return best[1]

    def refine(self,n,p,factors,envelope):
        # Epigraph minimax of BOTH boundary criteria with exact individual turns.
        cache_x=None; cache_r=None
        def residual(v):
            nonlocal cache_x,cache_r
            if cache_x is None or not np.array_equal(v[:6],cache_x):
                cache_x=v[:6].copy()
                cache_r=np.r_[self.residuals(self.exact_field(n,v[:6],factors))]/0.1
            return cache_r
        def inequalities(v):
            r=residual(v)
            return np.r_[v[-1]-r,v[-1]+r]
        x=np.r_[p,self.score(self.exact_field(n,p,factors))/0.1+1e-7]
        result=minimize(lambda v:v[-1],x,method="SLSQP",
            bounds=[(-envelope,envelope)]*6+[(0,2)],
            constraints=[{"type":"ineq","fun":inequalities}],
            options={"maxiter":100,"ftol":1e-10})
        if np.min(inequalities(result.x)) < -1e-6:
            raise RuntimeError("Exact minimax fit returned an infeasible result")
        return result.x[:6],result

    def record(self,name,n,p,factors,field,extras=None):
        normal,pressure=self.residuals(field)
        result={"case":name,"total_turns":int(np.dot(n,MULT)),
            "turns_by_group":{g:int(n[BLOCK[i]]) for i,g in enumerate(ORDER)},
            "center_R_Z_m":dict(zip(ORDER,shifted_centers(p).tolist())),
            "placement_parameters_m":np.asarray(p).tolist(),
            "pack_aspect_factors":np.asarray(factors).tolist(),
            "normal_max":float(np.max(abs(normal))),
            "normal_rms":float(np.sqrt(np.mean(normal**2))),
            "pressure_max":float(np.max(abs(pressure))),
            "pressure_rms":float(np.sqrt(np.mean(pressure**2))),
            "boundary_gate_pass":bool(np.max(abs(normal))<=GATE and np.max(abs(pressure))<=GATE),
            "current_scale_nominal":0.5,"sign_changes":False,
            "equilibrium_re_solved":False,"TF_changed":False,
            "normal_max_improvement_percent":float(100*(1-np.max(abs(normal))/np.max(abs(self.ref["normal"]))))}
        if extras:
            result.update(extras)
        return result,normal,pressure

    def save_case(self,result,n,p,factors,normal,pressure):
        name=result["case"]
        pos,amps,names=self.layout(n,p,factors)
        assert len(pos)==result["total_turns"]
        path=ROOT/(name+"_turn_placement.csv")
        header=["coil_id","turn_id","R_m","Z_m","signed_current_A",
                "operating_current_A","source_status"]
        counters={g:0 for g in ORDER}
        with path.open("w",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=header);writer.writeheader()
            for (r,z),amp,g in zip(pos,amps,names):
                counters[g]+=1
                writer.writerow({"coil_id":g,"turn_id":f"{g}_T{counters[g]:04d}",
                    "R_m":f"{r:.10f}","Z_m":f"{z:.10f}",
                    "signed_current_A":f"{2*amp:.10f}","operating_current_A":f"{amp:.10f}",
                    "source_status":"EXPLORATORY_FIXED_EQUILIBRIUM_SCREEN_NOT_GATE_CLOSED"})
        np.savez_compressed(ROOT/(name+"_residuals.npz"),normal=normal,pressure=pressure)
        (ROOT/(name+".json")).write_text(json.dumps(result,indent=2)+"\n")


def run_screen(budgets=(578,606,634),envelopes=(0.5,1.0)):
    study=Study()
    cases=[]
    baseline,_,_=study.record("reference",BASE_N,np.zeros(6),np.ones(4),study.old_pf)
    cases.append(baseline)
    for budget in budgets:
        for envelope in envelopes:
            name=f"PF{budget}_placement_{envelope:g}m".replace(".","p")
            print(f"Screening {name}",flush=True)
            best,trials=study.continuous_fit(budget,envelope)
            p=best["x"][4:10]
            n=study.round_counts(best["x"][:4]*BASE_N,p,budget)
            # Test compact, original-aspect and elongated packs, plus individual changes.
            layouts=[np.full(4,x) for x in (0.5,1.,2.)]
            for i in range(4):
                for value in (0.5,2.):
                    f=np.ones(4);f[i]=value;layouts.append(f)
            evaluated=[(study.score(study.exact_field(n,p,f)),f) for f in layouts]
            factors=min(evaluated,key=lambda r:r[0])[1]
            p,optimizer=study.refine(n,p,factors,envelope)
            field=study.exact_field(n,p,factors)
            result,normal,pressure=study.record(name,n,p,factors,field,{
                "placement_envelope_m":envelope,"fractional_turn_initializer":(best["x"][:4]*BASE_N).tolist(),
                "continuous_solver_starts":[{k:v for k,v in r.items() if k!="x"} for r in trials],
                "exact_optimizer_success":bool(optimizer.success),"exact_optimizer_message":str(optimizer.message),
                "aspect_layouts_evaluated":len(evaluated)})
            study.save_case(result,n,p,factors,normal,pressure)
            cases.append(result)
            (ROOT/"screen_results.json").write_text(json.dumps(cases,indent=2)+"\n")
            print(json.dumps({k:result[k] for k in ("case","turns_by_group","normal_max",
                  "pressure_max","normal_max_improvement_percent","boundary_gate_pass")}),flush=True)
    return cases


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--budget",type=int,nargs="+",default=[578,606,634])
    parser.add_argument("--envelope",type=float,nargs="+",default=[0.5,1.0])
    args=parser.parse_args()
    run_screen(args.budget,args.envelope)

if __name__=="__main__":
    main()
