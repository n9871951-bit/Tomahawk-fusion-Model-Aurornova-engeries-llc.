# Tomahawk PF winding, placement, RF and timing study

## Result

**A useful winding direction was identified; the G2 boundary gates remain open.**

The strongest tested candidate that preserves the starting minimum PF-to-TF centerline separation uses **634 PF turns (+56, +9.69%)**, redistributes turns among the six groups, reverses each PF group's signed winding direction, and changes pack placement. Its maximum normalized boundary-normal error falls from **0.0813010 to 0.0556173 (31.59%)**. The limit is **0.001**. Its boundary magnetic-pressure error is **0.0114243**, also above **0.001**.

This candidate is a starting point for the geometry/equilibrium design pass. No final winding design has been accepted, no full replacement MGRID has been generated, and no electrical-power gain is claimed.

## What was calculated

- Six cases: 578, 606 and 634 total turns, each with symmetric pack-center movements bounded by 0.5 m or 1.0 m per placement parameter.
- Within those cases, each independent group count was bounded between 75% and 150% of its original count, with an exact total-turn constraint. Upper/lower partners have equal turn counts and mirrored positions.
- Eleven packing aspect choices per case, using the source **29.7 mm** turn-center pitch. Integer turn layouts were evaluated individually after a continuous center-ring initialization.
- Sixteen combinations of winding direction at 634 turns, followed by exact individual-turn evaluation of the best initialization.
- Two further placement fits preserving the original minimum PF-to-TF centerline separation, including an explicit bound for TF segment sampling error.
- A broader count-allocation diagnostic with a one-turn minimum per group. It concentrated almost all turns into the paired inner groups and still failed; it is recorded only as an approximate diagnostic, with no layout proposed.

These are local constrained searches. They do not establish a global optimum or rule out every possible coil topology.

### Boundary results

| Case | PF turns | Maximum normal error | Maximum pressure error | Result |
|---|---:|---:|---:|---|
| Saved high-pressure reference | 578 | 0.0813010 | 0.0124612 | Fail |
| Redistributed turns, original winding directions, 1 m placement envelope | 578 | 0.0780513 | 0.0123528 | Fail |
| Same search with modest turn addition | 606 | 0.0786077 | 0.0123850 | Fail |
| Same search with larger addition | 634 | 0.0791643 | 0.0124163 | Fail |
| Reversed winding directions, unconstrained separation diagnostic | 634 | 0.0544717 | 0.0117764 | Fail; only 19 mm sampled TF centerline separation |
| Original directions with source separation preserved | 578 | 0.0781270 | 0.0123534 | Fail |
| **Reversed directions with source separation preserved** | **634** | **0.0556173** | **0.0114243** | **Fail; retained for geometry study** |
| Required limit | — | **≤0.001** | **≤0.001** | Both required |

Adding turns within the original winding directions and the tested allocation bounds did not improve on redistribution alone. Reversing the winding directions produced the larger improvement. The near-contact diagnostic is not the geometry-study candidate.

## Candidate to use as an initial geometry study

File: `PF634_reversed_sense_diagnostic_separation_guard_turn_placement.csv`.

| PF group | Original turns | Candidate turns | Center R (m) | Center Z (m) | Signed operating current per turn (A) |
|---|---:|---:|---:|---:|---:|
| PF_L_IN | 28 | 21 | 5.000000 | −5.168043 | −9,561.748835 |
| PF_L_OUT | 162 | 221 | 10.000000 | −3.793970 | −9,952.137049 |
| PF_M_IN | 48 | 36 | 2.526479 | 0 | +9,697.801820 |
| PF_M_OUT | 150 | 114 | 12.547563 | 0 | −9,652.377627 |
| PF_U_IN | 28 | 21 | 5.000000 | +5.168043 | −9,561.748835 |
| PF_U_OUT | 162 | 221 | 10.000000 | +3.793970 | −9,952.137049 |
| **Total** | **578** | **634** | | | |

Current magnitudes are the saved operating magnitudes: 0.5 times the original nominal magnitudes. Every PF sign is reversed relative to the source CSV. The exported `signed_current_A` column is the candidate signed nominal current; `operating_current_A` is the signed current actually used in this screen. A downstream reader must use the operating column or apply the 0.5 multiplier once to the nominal column.

The candidate has a sampled PF-to-TF centerline minimum of **0.670571 m**, with a conservative segment-sampling lower bound of **0.667350 m**. Its minimum sampled PF turn-center distance to the saved plasma surface is **1.881269 m**. These quantities do not include TF winding envelopes, insulation, supports or services. The 29.7 mm pitch is inherited from the source centerlines; conductor and insulation dimensions have not been inferred from it.

The legacy assembly runner expects 578 turns. The 634-turn CSV is an input for the upcoming geometry revision, not a drop-in file for that unchanged runner. Its group-count validation and winding direction handling must be updated in the geometry stage.

## RF revision

The saved high-pressure equilibrium's magnetic axis at the RF stations' common field-period phase is at **R=7.793472 m**, with total plasma field magnitude **15.8504365 T**. The calculated deuterium fundamental frequency there is **120.881417 MHz**.

`RF4_next_geometry_candidate.csv` proposes **120.881417 MHz** at the four existing station envelopes. `RF_study_plan.json` retains comparison frequencies of **107.4**, **120.881417**, and **122.037239 MHz**.

The previous 122.037239 MHz estimate used the external field at nominal R=7.5 m. It did not use the actual magnetic axis of the saved equilibrium. The new value uses that axis, but it must be recomputed after the revised winding design is matched to a new equilibrium. Launcher placement is retained as a starting envelope for the next geometry pass.

This is a resonance-frequency calculation. No RF absorption, deposited-power increase, transmitter capability or gain in net electrical output has been calculated. The saved equilibrium contains a pressure profile but no separate density, electron-temperature or ion-temperature profiles for a full-wave absorption calculation. No helium minority is assumed. Published ICRF work shows why absorption, antenna spectrum and edge coupling need their own calculations: [Lin, Wright and Wukitch, *Physics basis for the ICRF system of the SPARC tokamak*](https://www.cambridge.org/core/journals/journal-of-plasma-physics/article/physics-basis-for-the-icrf-system-of-the-sparc-tokamak/22016DD64F3C5CAD47563A1E4AE59934).

## Timing proposal

`timing_proposal.json` interprets timing as coil-current ramps and RF turn-on sequencing. It proposes a smooth quintic current ramp and event conditions for establishing the TF field, settling PF currents, checking RF coupling, raising pressure, and holding the target state.

Durations, settling tolerances and RF power are explicitly unset. The supplied files do not specify the circuit inductance matrix, supply voltage/slew limits or transient plasma/circuit response needed to calculate them. There has been no transient timing simulation. Changing the ramp timing does not alter this fixed-equilibrium screen at the same final currents; no reduction of the static boundary error has been assigned to timing or RF.

## Numerical basis and validation

The reference is the saved `combined_high_pressure.h5`, with central pressure **1,329,000.621 Pa**, unchanged iota profile and toroidal flux. The TF source has 48 centerlines; TF current stays at **−125,000 A per turn**. The existing exact 16 T MGRID is the reference field.

The reference was rebuilt using DESC 0.17.3. Its normal residual agrees exactly with the saved result; the largest pressure-residual difference is **2.43×10⁻¹⁶**. The exact MGRID SHA-256 is stored in `reference_metadata.json`.

At the fixed boundary, the screen adds the analytic circular-turn PF field change to the exact reference field:

`normal_new = normal_old + dot(delta_B, n) * area_factor / normal_scale`

`pressure_new = pressure_old - (2*dot(B_out_old, delta_B) + dot(delta_B, delta_B)) * area_factor / pressure_scale`

The cached exterior total field includes the plasma contribution used by DESC. The boundary has 555 nodes (M=18, N=7, NFP=16). The coil field implementation agrees with independent numerical Biot–Savart quadrature to **2.99×10⁻¹⁵ relative error** for the recorded check. Exported decimal coordinates and operating currents reproduce all saved candidate scores; integer counts, unique identifiers, mirrored partners and minimum pitch were checked. See `validation.json`.

The equilibrium and plasma profiles were held fixed while changing external PF fields. These results are a field-matching screen, not a new free-boundary solution. The previous pressure and ballooning results do not certify a new matched equilibrium for these windings.

## Next geometry pass

1. Start from the 634-turn candidate above and retain the 578-turn separation-preserving case as a control.
2. Fit the plasma boundary and equilibrium to the revised winding fields at the requested pressure. Check the declared boundary normal and magnetic-pressure limits throughout. CAD separation and plasma boundary matching both need to be satisfied.
3. Build the resulting coil and RF geometry, including actual conductor/support envelopes, updated turn counts, circuit winding directions, and BREP/group checks.
4. Recompute the RF resonance and absorption study using that equilibrium and the required species profiles.
5. Rebuild the full MGRID from the accepted geometry, then verify the coupled equilibrium and declared stability/power-balance checks.

## Reproduce the inexpensive winding screen

The core screen uses the included exact-reference cache, so no large input map, internet download or hardcoded Windows/Kaggle path is needed. Run these commands from this extracted folder:

```bash
python -m pip install -r requirements_screen.txt
python screen_windings.py
python diagnostics.py
python clearance_constrained_fit.py
python validate_layouts.py
```

These are numerical winding screens, not the earlier long coupled Kaggle campaign. Runtime is determined by the calculations; no delays are added. Scripts find their inputs relative to their own location.

`check_clearance.py` additionally uses DESC and the included equilibrium to regenerate the sampled plasma-surface distances:

```bash
python -m pip install -r requirements_optional_desc.txt
python check_clearance.py
```

The executed environment was Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and DESC 0.17.3. All Python files were syntax checked. The 651 MB input MGRID is not duplicated here; it remains in the original corrected input archive. The reference cache, hashes, source centerlines, candidate layouts, equilibrium, residual arrays and results are included.
