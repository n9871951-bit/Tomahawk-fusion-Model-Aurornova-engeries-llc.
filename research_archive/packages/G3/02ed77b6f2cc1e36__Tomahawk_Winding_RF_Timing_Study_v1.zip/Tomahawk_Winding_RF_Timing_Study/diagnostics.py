"""Extra allocation and winding-sense screens; rerunnable without DESC."""
import itertools
import json
import numpy as np
from screen_windings import ROOT, Study, BASE_N, BLOCK


def main():
    study=Study()
    original_currents=study.operating.copy()
    cases=[]
    for signs in itertools.product((-1,1),repeat=4):
        study.operating=original_currents*np.asarray(signs)[BLOCK]
        fit,_=study.continuous_fit(634,1.)
        p=fit["x"][4:10]
        n=study.round_counts(fit["x"][:4]*BASE_N,p,634)
        normal,pressure=study.residuals(study.thin_field(n,p))
        result={"sign_multipliers":list(signs),"counts":n.tolist(),
                "placement":p.tolist(),"thin_normal_max":float(np.max(abs(normal))),
                "thin_pressure_max":float(np.max(abs(pressure))),
                "thin_objective_max":float(max(np.max(abs(normal)),np.max(abs(pressure))))}
        cases.append(result)
        print(result,flush=True)
    (ROOT/"winding_sense_initial.json").write_text(json.dumps(cases,indent=2)+"\n")
    top=min(cases,key=lambda r:r["thin_objective_max"])
    signs=np.asarray(top["sign_multipliers"])
    study.operating=original_currents*signs[BLOCK]
    n=np.asarray(top["counts"]);p=np.asarray(top["placement"])
    factors=min([np.full(4,v) for v in (.5,1.,2.)],
                key=lambda f:study.score(study.exact_field(n,p,f)))
    p,opt=study.refine(n,p,factors,1.)
    record,bn,bp=study.record("PF634_reversed_sense_diagnostic",n,p,factors,
        study.exact_field(n,p,factors),{"sign_changes":True,"sign_multipliers":signs.tolist(),
        "selection_status":"DIAGNOSTIC_REQUIRES_WINDING_CIRCUIT_DIRECTION_CHANGE",
        "exact_optimizer_success":bool(opt.success),"exact_optimizer_message":str(opt.message)})
    study.save_case(record,n,p,factors,bn,bp)
    # Optimistic center-ring diagnostic with only one turn minimum per group.
    # Do not export a proposed pack: these allocations effectively discard groups.
    study.operating=original_currents
    study.lo=np.ones(4,dtype=int);study.hi=np.array([317,317,634,634])
    broad=[]
    for budget in (578,634):
        for envelope in (.5,1.):
            fit,_=study.continuous_fit(budget,envelope)
            p=fit["x"][4:10]
            n=study.round_counts(fit["x"][:4]*BASE_N,p,budget)
            normal,pressure=study.residuals(study.thin_field(n,p))
            broad.append({"budget":budget,"envelope":envelope,"counts":n.tolist(),
                "placement":p.tolist(),"thin_normal_max":float(np.max(abs(normal))),
                "thin_pressure_max":float(np.max(abs(pressure)))})
    (ROOT/"broader_allocation_initial.json").write_text(json.dumps(broad,indent=2)+"\n")

if __name__=="__main__":
    main()
